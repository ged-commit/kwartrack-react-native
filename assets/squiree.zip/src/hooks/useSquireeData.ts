import { useState, useEffect } from 'react';

export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  amount: number;
  category: string;
  date: string;
  description: string;
  type: TransactionType;
}

export interface Budget {
  category: string;
  limit: number;
}

export interface SavingsGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  deadline?: string;
}

export interface Debt {
  id: string;
  name: string;
  amount: number;
  type: 'owe' | 'owed';
  dueDate?: string;
}

export interface Account {
  id: string;
  name: string;
  balance: number;
  type: string;
}

export function useSquireeData() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const savedTransactions = localStorage.getItem('squiree_transactions');
    const savedBudgets = localStorage.getItem('squiree_budgets');
    const savedGoals = localStorage.getItem('squiree_goals');
    const savedDebts = localStorage.getItem('squiree_debts');
    const savedAccounts = localStorage.getItem('squiree_accounts');

    if (savedTransactions) setTransactions(JSON.parse(savedTransactions));
    if (savedBudgets) setBudgets(JSON.parse(savedBudgets));
    if (savedGoals) setGoals(JSON.parse(savedGoals));
    if (savedDebts) setDebts(JSON.parse(savedDebts));
    if (savedAccounts) {
      setAccounts(JSON.parse(savedAccounts));
    } else {
      // Default accounts
      setAccounts([
        { id: '1', name: 'BPI Savings', balance: 28450, type: 'Debit' },
        { id: '2', name: 'GCash', balance: 6420, type: 'E-Wallet' },
        { id: '3', name: 'Cash', balance: 1250, type: 'Cash' }
      ]);
    }
    
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem('squiree_transactions', JSON.stringify(transactions));
      localStorage.setItem('squiree_budgets', JSON.stringify(budgets));
      localStorage.setItem('squiree_goals', JSON.stringify(goals));
      localStorage.setItem('squiree_debts', JSON.stringify(debts));
      localStorage.setItem('squiree_accounts', JSON.stringify(accounts));
    }
  }, [transactions, budgets, goals, debts, accounts, isLoaded]);

  const addTransaction = (t: Omit<Transaction, 'id'>) => {
    const newT = { ...t, id: crypto.randomUUID() };
    setTransactions(prev => [newT, ...prev]);
    
    // Update account balance
    setAccounts(prev => prev.map(acc => {
      if (acc.name === t.category) { // Simplified: using category as account for now or we should add accountId to Transaction
        return { ...acc, balance: t.type === 'income' ? acc.balance + t.amount : acc.balance - t.amount };
      }
      return acc;
    }));
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const addBudget = (b: Budget) => {
    setBudgets(prev => {
      const existing = prev.findIndex(item => item.category === b.category);
      if (existing > -1) {
        const updated = [...prev];
        updated[existing] = b;
        return updated;
      }
      return [...prev, b];
    });
  };

  const addGoal = (g: Omit<SavingsGoal, 'id'>) => {
    setGoals(prev => [...prev, { ...g, id: crypto.randomUUID() }]);
  };

  const updateGoal = (id: string, current: number) => {
    setGoals(prev => prev.map(g => g.id === id ? { ...g, current } : g));
  };

  const addDebt = (d: Omit<Debt, 'id'>) => {
    setDebts(prev => [...prev, { ...d, id: crypto.randomUUID() }]);
  };

  const deleteDebt = (id: string) => {
    setDebts(prev => prev.filter(d => d.id !== id));
  };

  const addAccount = (acc: Omit<Account, 'id'>) => {
    setAccounts(prev => [...prev, { ...acc, id: crypto.randomUUID() }]);
  };

  return {
    transactions,
    budgets,
    goals,
    debts,
    accounts,
    addTransaction,
    deleteTransaction,
    addBudget,
    addGoal,
    updateGoal,
    addDebt,
    deleteDebt,
    addAccount
  };
}
