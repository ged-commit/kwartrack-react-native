/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  Wallet, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  PieChart as PieChartIcon, 
  Target, 
  HandCoins, 
  History,
  LayoutDashboard,
  X,
  ChevronRight,
  ArrowUpRight,
  ArrowDownLeft,
  Settings,
  CreditCard,
  Calendar,
  MessageCircle,
  Trash2,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { format, parseISO, startOfMonth, endOfMonth, isWithinInterval, isToday } from 'date-fns';
import { useSquireeData, Transaction, TransactionType, Budget, SavingsGoal, Debt, Account } from './hooks/useSquireeData';

type View = 'dashboard' | 'wallet' | 'transactions' | 'settings';

export default function App() {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'transaction' | 'budget' | 'goal' | 'debt' | 'account'>('transaction');
  
  const { 
    transactions, 
    budgets, 
    goals, 
    debts, 
    accounts,
    addTransaction, 
    deleteTransaction,
    addBudget,
    addGoal,
    updateGoal,
    addDebt,
    deleteDebt,
    addAccount
  } = useSquireeData();

  const stats = useMemo(() => {
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((acc, t) => acc + t.amount, 0);
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => acc + t.amount, 0);
    const spentToday = transactions
      .filter(t => t.type === 'expense' && isToday(parseISO(t.date)))
      .reduce((acc, t) => acc + t.amount, 0);
    const totalBalance = accounts.reduce((acc, a) => acc + a.balance, 0);
    
    return {
      balance: totalBalance,
      income,
      expenses,
      spentToday
    };
  }, [transactions, accounts]);

  const chartData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return format(d, 'yyyy-MM-dd');
    }).reverse();

    return last7Days.map(date => {
      const dayTransactions = transactions.filter(t => t.date === date);
      const expense = dayTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
      return {
        name: format(parseISO(date), 'EE').charAt(0),
        expense
      };
    });
  }, [transactions]);

  const budgetProgress = useMemo(() => {
    const currentMonth = { start: startOfMonth(new Date()), end: endOfMonth(new Date()) };
    return budgets.map(b => {
      const spent = transactions
        .filter(t => 
          t.type === 'expense' && 
          t.category === b.category && 
          isWithinInterval(parseISO(t.date), currentMonth)
        )
        .reduce((acc, t) => acc + t.amount, 0);
      return { ...b, spent };
    });
  }, [budgets, transactions]);

  const openModal = (type: 'transaction' | 'budget' | 'goal' | 'debt' | 'account') => {
    setModalType(type);
    setIsAddModalOpen(true);
  };

  return (
    <div className="max-w-md mx-auto min-h-screen pb-32 px-5 pt-12 relative text-white overflow-x-hidden">
      {/* Background Accents */}
      <div className="fixed top-0 left-0 w-full h-full bg-forest -z-20" />
      <div className="fixed top-[-10%] left-[-10%] w-[60%] h-[40%] bg-gold/10 blur-[120px] rounded-full -z-10" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[60%] h-[40%] bg-forest-light/20 blur-[120px] rounded-full -z-10" />

      <AnimatePresence mode="wait">
        {activeView === 'dashboard' && (
          <motion.div 
            key="dashboard"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            {/* Header */}
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-gold/60 uppercase tracking-[0.2em]">{format(new Date(), 'EEEE, MMMM d')}</p>
              <h1 className="text-3xl font-bold">Good morning, <span className="text-gold">Jamie!</span></h1>
            </div>

            {/* Mascot Card */}
            <div className="liquid-glass rounded-[40px] p-6 flex gap-5 items-center relative overflow-hidden group">
              <div className="w-20 h-20 bg-gold/20 rounded-3xl flex items-center justify-center overflow-hidden flex-shrink-0 border border-gold/30 shadow-inner">
                <img 
                  src="https://api.dicebear.com/7.x/bottts/svg?seed=squirrel&backgroundColor=D4AF37" 
                  alt="Squiree Mascot" 
                  className="w-16 h-16 drop-shadow-lg"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-1 relative z-10">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-gold uppercase tracking-widest">Squiree Advisor</span>
                </div>
                <p className="text-sm text-white/80 leading-relaxed font-medium">
                  "Every acorn saved is a forest for tomorrow. You're doing great, Jamie!"
                </p>
              </div>
              <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-gold/5 rounded-full blur-2xl group-hover:bg-gold/10 transition-all duration-700" />
            </div>

            {/* Stats Row */}
            <div className="grid grid-cols-2 gap-5">
              <div className="liquid-glass rounded-[40px] p-6 space-y-4">
                <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Activity</p>
                <div className="h-20 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <Bar dataKey="expense" fill="#D4AF37" radius={[6, 6, 0, 0]} barSize={12} />
                      <XAxis dataKey="name" hide />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="liquid-glass rounded-[40px] p-6 flex flex-col justify-between">
                <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Spent Today</p>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-white">₱{stats.spentToday.toLocaleString()}</p>
                  <p className="text-[10px] font-bold text-gold/60 uppercase">Keep it up!</p>
                </div>
              </div>
            </div>

            {/* Monthly Budgets Section */}
            <div className="space-y-5">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-xl font-bold text-gold-light">Monthly Budgets</h3>
                <button onClick={() => openModal('budget')} className="text-[10px] font-bold text-gold uppercase tracking-widest hover:text-white transition-colors">Manage</button>
              </div>
              <div className="liquid-glass rounded-[40px] p-8 space-y-8">
                {budgetProgress.length > 0 ? budgetProgress.map(b => (
                  <div key={b.category} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-2.5 h-2.5 rounded-full bg-gold shadow-[0_0_10px_rgba(212,175,55,0.5)]" />
                        <span className="font-bold text-base">{b.category}</span>
                      </div>
                      <span className="text-xs font-bold text-white/40">₱{b.spent.toLocaleString()} / ₱{b.limit.toLocaleString()}</span>
                    </div>
                    <div className="h-3 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-gold/60 to-gold rounded-full transition-all duration-1000"
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((b.spent / b.limit) * 100, 100)}%` }}
                      />
                    </div>
                    <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">₱{(b.limit - b.spent).toLocaleString()} remaining</p>
                  </div>
                )) : (
                  <p className="text-center text-white/20 text-sm italic py-4">No acorns sorted yet.</p>
                )}
              </div>
            </div>

            {/* Goals Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-forest">Goals</h3>
                <button onClick={() => openModal('goal')} className="text-xs font-bold text-emerald-600 uppercase">View All</button>
              </div>
              <div className="space-y-3">
                {goals.map(g => (
                  <div key={g.id} className="bg-white rounded-[32px] p-6 shadow-sm border border-emerald-50 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-sm">{g.name}</h4>
                        <p className="text-xs font-bold text-forest/40">₱{g.current.toLocaleString()} / ₱{g.target.toLocaleString()}</p>
                      </div>
                      <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">
                        {Math.round((g.current / g.target) * 100)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full transition-all duration-700"
                        style={{ width: `${Math.min((g.current / g.target) * 100, 100)}%` }}
                      />
                    </div>
                    <p className="text-[10px] font-bold text-forest/30">₱{(g.target - g.current).toLocaleString()} left to go</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Debt Section */}
            <div className="bg-white rounded-[32px] p-6 shadow-sm border border-emerald-50 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600">
                  <HandCoins className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm">Debt</h4>
                  <p className="text-xs font-bold text-forest/40">{debts.length} active debts</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-forest">₱{debts.reduce((acc, d) => acc + d.amount, 0).toLocaleString()}</p>
                <button onClick={() => setActiveView('dashboard')} className="text-[10px] font-bold text-forest/30 uppercase tracking-widest">View Details</button>
              </div>
            </div>
          </motion.div>
        )}

        {activeView === 'wallet' && (
          <motion.div 
            key="wallet"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-8"
          >
            <div className="flex items-center justify-between px-2">
              <h2 className="text-3xl font-bold text-white">Wallet</h2>
              <button onClick={() => openModal('account')} className="liquid-glass text-gold px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest border border-gold/20">
                + Add
              </button>
            </div>
            
            <div className="liquid-glass rounded-[40px] p-8 flex items-center justify-between relative overflow-hidden border border-white/10">
              <div className="relative z-10">
                <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-2">Total Balance</p>
                <h3 className="text-4xl font-black text-gold">₱{stats.balance.toLocaleString()}</h3>
              </div>
              <div className="w-16 h-16 liquid-glass rounded-3xl flex items-center justify-center text-gold/40 border border-white/10">
                <CreditCard className="w-8 h-8" />
              </div>
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-gold/5 rounded-full blur-3xl" />
            </div>

            <div className="space-y-5">
              <h3 className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] ml-4">My Accounts</h3>
              {accounts.map(acc => (
                <div key={acc.id} className="liquid-glass rounded-[40px] p-6 flex items-center justify-between border border-white/5 hover:bg-white/10 transition-colors">
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-gold/10 rounded-3xl flex items-center justify-center text-gold border border-gold/20">
                      <Wallet className="w-7 h-7" />
                    </div>
                    <div>
                      <h4 className="font-bold text-base text-white">{acc.name}</h4>
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">{acc.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-white">₱{acc.balance.toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeView === 'transactions' && (
          <motion.div 
            key="transactions"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            className="space-y-8"
          >
            <div className="space-y-1 px-2">
              <p className="text-[10px] font-black text-gold/60 uppercase tracking-[0.2em]">Monthly Overview</p>
              <h2 className="text-3xl font-bold text-white">History</h2>
            </div>

            <div className="liquid-glass rounded-[40px] p-8 flex flex-col items-center gap-8 border border-white/10">
              <div className="flex items-center justify-between w-full">
                <button className="p-3 hover:bg-white/10 rounded-2xl transition-colors text-white/40"><ChevronRight className="w-6 h-6 rotate-180" /></button>
                <h3 className="font-black text-gold uppercase tracking-widest">{format(new Date(), 'MMMM yyyy')}</h3>
                <button className="p-3 hover:bg-white/10 rounded-2xl transition-colors text-white/40"><ChevronRight className="w-6 h-6" /></button>
              </div>
              
              <div className="relative w-40 h-40 flex items-center justify-center">
                <div className="absolute inset-0 border-[12px] border-white/5 rounded-full" />
                <div className="absolute inset-0 border-[12px] border-gold rounded-full shadow-[0_0_20px_rgba(212,175,55,0.3)]" style={{ clipPath: 'polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 50%)' }} />
                <div className="text-center z-10">
                  <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Net</p>
                  <p className="text-2xl font-black text-white">₱{(stats.income - stats.expenses).toLocaleString()}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-10 w-full">
                <div className="text-center space-y-1">
                  <p className="text-[10px] font-black text-gold uppercase tracking-widest">Income</p>
                  <p className="text-xl font-bold text-white">+₱{stats.income.toLocaleString()}</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">Spent</p>
                  <p className="text-xl font-bold text-white">-₱{stats.expenses.toLocaleString()}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {transactions.map(t => (
                <div key={t.id} className="liquid-glass rounded-[40px] p-5 flex items-center justify-between border border-white/5 hover:bg-white/10 transition-colors">
                   <div className="flex items-center gap-5">
                    <div className={`w-14 h-14 rounded-3xl flex items-center justify-center border ${
                      t.type === 'income' ? 'bg-gold/10 text-gold border-gold/20' : 'bg-red-500/10 text-red-400 border-red-500/20'
                    }`}>
                      {t.type === 'income' ? <TrendingUp className="w-7 h-7" /> : <TrendingDown className="w-7 h-7" />}
                    </div>
                    <div>
                      <p className="font-bold text-base text-white">{t.description}</p>
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">{t.category} • {format(parseISO(t.date), 'MMM d')}</p>
                    </div>
                  </div>
                  <p className={`text-lg font-black ${t.type === 'income' ? 'text-gold' : 'text-red-400'}`}>
                    {t.type === 'income' ? '+' : '-'}₱{t.amount.toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeView === 'settings' && (
          <motion.div 
            key="settings"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            <h2 className="text-3xl font-bold text-white px-2">Settings</h2>
            <div className="liquid-glass rounded-[40px] p-4 border border-white/10 divide-y divide-white/5">
              <SettingsItem icon={<Settings className="w-6 h-6" />} label="General Settings" />
              <SettingsItem icon={<CreditCard className="w-6 h-6" />} label="Subscription" />
              <SettingsItem icon={<Calendar className="w-6 h-6" />} label="Reminders" />
              <SettingsItem icon={<MessageCircle className="w-6 h-6" />} label="Support" />
            </div>
            <div className="liquid-glass rounded-[40px] p-4 border border-white/10">
              <button 
                onClick={() => {
                  if(confirm('Clear all data?')) {
                    localStorage.clear();
                    window.location.reload();
                  }
                }}
                className="w-full flex items-center justify-between p-5 text-red-400 font-black uppercase tracking-widest text-xs"
              >
                <div className="flex items-center gap-4">
                  <Trash2 className="w-6 h-6" />
                  <span>Reset Data</span>
                </div>
                <ChevronRight className="w-6 h-6 opacity-20" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button */}
      <button 
        onClick={() => openModal('transaction')}
        className="fixed bottom-28 right-6 bg-gradient-to-br from-gold to-gold-muted text-forest px-6 py-4 rounded-full font-black shadow-[0_8px_32px_rgba(212,175,55,0.3)] flex items-center gap-3 active:scale-90 transition-all z-30 uppercase tracking-widest text-sm"
      >
        <Plus className="w-6 h-6" strokeWidth={3} />
        Add Entry
      </button>

      {/* Navigation */}
      <nav className="fixed bottom-6 left-6 right-6 liquid-glass rounded-[40px] p-3 flex items-center justify-around border border-white/10 z-40">
        <NavButton active={activeView === 'dashboard'} onClick={() => setActiveView('dashboard')} icon={<LayoutDashboard />} label="Home" />
        <NavButton active={activeView === 'wallet'} onClick={() => setActiveView('wallet')} icon={<Wallet />} label="Wallet" />
        <NavButton active={activeView === 'transactions'} onClick={() => setActiveView('transactions')} icon={<History />} label="History" />
        <NavButton active={activeView === 'settings'} onClick={() => setActiveView('settings')} icon={<Settings />} label="Settings" />
      </nav>

      {/* Modals */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg liquid-glass rounded-t-[40px] sm:rounded-[40px] overflow-hidden flex flex-col max-h-[92vh] border-t border-white/20 sm:border"
            >
              <div className="p-8 overflow-y-auto custom-scrollbar">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-black text-gold uppercase tracking-widest">
                    {modalType === 'transaction' && 'New Entry'}
                    {modalType === 'budget' && 'New Budget'}
                    {modalType === 'goal' && 'New Goal'}
                    {modalType === 'debt' && 'New Debt'}
                    {modalType === 'account' && 'New Account'}
                  </h3>
                  <button 
                    onClick={() => setIsAddModalOpen(false)} 
                    className="p-3 hover:bg-white/10 rounded-2xl transition-colors text-white/40"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                {modalType === 'transaction' && (
                  <TransactionForm accounts={accounts} onSubmit={(t) => {
                    addTransaction(t);
                    setIsAddModalOpen(false);
                  }} />
                )}

                {modalType === 'budget' && (
                  <BudgetForm onSubmit={(b) => {
                    addBudget(b);
                    setIsAddModalOpen(false);
                  }} />
                )}

                {modalType === 'goal' && (
                  <GoalForm onSubmit={(g) => {
                    addGoal(g);
                    setIsAddModalOpen(false);
                  }} />
                )}

                {modalType === 'debt' && (
                  <DebtForm onSubmit={(d) => {
                    addDebt(d);
                    setIsAddModalOpen(false);
                  }} />
                )}

                {modalType === 'account' && (
                  <AccountForm onSubmit={(acc) => {
                    addAccount(acc);
                    setIsAddModalOpen(false);
                  }} />
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

const NavButton: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string }> = ({ active, onClick, icon, label }) => {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 p-3 rounded-2xl transition-all ${active ? 'bg-gold/20 text-gold' : 'text-white/30'}`}
    >
      {React.cloneElement(icon as React.ReactElement, { size: 24 })}
      <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
    </button>
  );
}

const SettingsItem: React.FC<{ icon: React.ReactNode, label: string }> = ({ icon, label }) => (
  <button className="w-full flex items-center justify-between p-6 text-white font-bold hover:bg-white/5 transition-colors rounded-[32px]">
    <div className="flex items-center gap-4 text-white/60">
      <div className="text-gold">{icon}</div>
      <span className="text-white text-base">{label}</span>
    </div>
    <ChevronRight className="w-6 h-6 text-white/10" />
  </button>
);

const TransactionForm: React.FC<{ accounts: Account[], onSubmit: (t: Omit<Transaction, 'id'>) => void }> = ({ accounts, onSubmit }) => {
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState('0');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [accountId, setAccountId] = useState(accounts[0]?.id || '');

  const categories = type === 'income' 
    ? ['Salary', 'Freelance', 'Investment', 'Gift', 'Other']
    : ['Food', 'Transport', 'Rent', 'Shopping', 'Health', 'Entertainment', 'Other'];

  const handleKeypad = (val: string) => {
    if (val === 'back') {
      setAmount(prev => prev.length > 1 ? prev.slice(0, -1) : '0');
    } else if (val === '.') {
      if (!amount.includes('.')) setAmount(prev => prev + '.');
    } else {
      setAmount(prev => prev === '0' ? val : prev + val);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex bg-white/5 p-2 rounded-[32px] border border-white/10">
        <button 
          onClick={() => setType('expense')}
          className={`flex-1 py-4 rounded-[24px] font-black uppercase tracking-widest text-xs transition-all ${type === 'expense' ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' : 'text-white/40'}`}
        >
          Expense
        </button>
        <button 
          onClick={() => setType('income')}
          className={`flex-1 py-4 rounded-[24px] font-black uppercase tracking-widest text-xs transition-all ${type === 'income' ? 'bg-gold text-forest shadow-lg shadow-gold/20' : 'text-white/40'}`}
        >
          Income
        </button>
      </div>

      <div className="text-center space-y-4">
        <p className="text-6xl font-black text-gold tracking-tight">₱{amount}</p>
        <input 
          type="text" 
          placeholder="What was it for?"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full text-center bg-transparent border-none focus:ring-0 text-base font-bold text-white/40 placeholder:text-white/20"
        />
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <p className="text-[10px] font-black text-gold/60 uppercase tracking-[0.2em] ml-2">Account</p>
          <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar px-2">
            {accounts.map(acc => (
              <button 
                key={acc.id}
                onClick={() => setAccountId(acc.id)}
                className={`flex-shrink-0 p-4 rounded-[28px] border-2 transition-all text-left min-w-[120px] ${
                  accountId === acc.id ? 'border-gold bg-gold/10' : 'border-white/5 bg-white/5'
                }`}
              >
                <p className="font-bold text-xs text-white">{acc.name}</p>
                <p className="text-[10px] font-bold text-white/40 uppercase">₱{acc.balance.toLocaleString()}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <p className="text-[10px] font-black text-gold/60 uppercase tracking-[0.2em] ml-2">Category</p>
          <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar px-2">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => setCategory(cat)}
                className={`flex-shrink-0 px-6 py-3 rounded-full border-2 transition-all text-xs font-black uppercase tracking-widest ${
                  category === cat ? 'border-gold bg-gold text-forest' : 'border-white/5 bg-white/5 text-white/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '.', 0, 'back'].map(k => (
          <button 
            key={k}
            onClick={() => handleKeypad(k.toString())}
            className="h-16 liquid-glass rounded-2xl flex items-center justify-center font-black text-xl active:bg-white/10 transition-colors text-white border border-white/5"
          >
            {k === 'back' ? <X size={24} /> : k}
          </button>
        ))}
      </div>

      <button 
        onClick={() => onSubmit({ amount: parseFloat(amount), type, category, description, date: new Date().toISOString(), accountId })}
        disabled={parseFloat(amount) === 0 || !category}
        className="btn-gold w-full py-5 rounded-[32px] disabled:opacity-30 disabled:grayscale"
      >
        Save Transaction
      </button>
    </div>
  );
}

const BudgetForm: React.FC<{ onSubmit: (b: Budget) => void }> = ({ onSubmit }) => {
  const [category, setCategory] = useState('');
  const [limit, setLimit] = useState('');

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <input 
          type="text" 
          placeholder="Category Name"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="input-glass w-full"
        />
        <input 
          type="number" 
          placeholder="Monthly Limit"
          value={limit}
          onChange={(e) => setLimit(e.target.value)}
          className="input-glass w-full"
        />
      </div>
      <button 
        onClick={() => onSubmit({ category, limit: parseFloat(limit) })}
        className="btn-gold w-full py-5 rounded-[32px]"
      >
        Create Budget
      </button>
    </div>
  );
}

const GoalForm: React.FC<{ onSubmit: (g: Omit<SavingsGoal, 'id'>) => void }> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <input 
          type="text" 
          placeholder="Goal Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input-glass w-full"
        />
        <input 
          type="number" 
          placeholder="Target Amount"
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          className="input-glass w-full"
        />
      </div>
      <button 
        onClick={() => onSubmit({ name, target: parseFloat(target), current: 0 })}
        className="btn-gold w-full py-5 rounded-[32px]"
      >
        Start Saving
      </button>
    </div>
  );
}

const DebtForm: React.FC<{ onSubmit: (d: Omit<Debt, 'id'>) => void }> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'owe' | 'owed'>('owe');

  return (
    <div className="space-y-8">
      <div className="flex gap-3 p-1.5 liquid-glass rounded-2xl">
        <button 
          onClick={() => setType('owe')}
          className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${type === 'owe' ? 'bg-gold text-forest shadow-lg' : 'text-white/30'}`}
        >
          I Owe
        </button>
        <button 
          onClick={() => setType('owed')}
          className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${type === 'owed' ? 'bg-gold text-forest shadow-lg' : 'text-white/30'}`}
        >
          Owed to Me
        </button>
      </div>
      <div className="space-y-4">
        <input 
          type="text" 
          placeholder="Person/Entity Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input-glass w-full"
        />
        <input 
          type="number" 
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="input-glass w-full"
        />
      </div>
      <button 
        onClick={() => onSubmit({ name, amount: parseFloat(amount), type })}
        className="btn-gold w-full py-5 rounded-[32px]"
      >
        Add Debt
      </button>
    </div>
  );
}

const AccountForm: React.FC<{ onSubmit: (acc: Omit<Account, 'id'>) => void }> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [balance, setBalance] = useState('');
  const [type, setType] = useState('Debit');

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <input 
          type="text" 
          placeholder="Account Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input-glass w-full"
        />
        <input 
          type="number" 
          placeholder="Initial Balance"
          value={balance}
          onChange={(e) => setBalance(e.target.value)}
          className="input-glass w-full"
        />
        <select 
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="input-glass w-full appearance-none"
        >
          <option className="bg-forest">Debit</option>
          <option className="bg-forest">E-Wallet</option>
          <option className="bg-forest">Cash</option>
          <option className="bg-forest">Credit</option>
        </select>
      </div>
      <button 
        onClick={() => onSubmit({ name, balance: parseFloat(balance), type })}
        className="btn-gold w-full py-5 rounded-[32px]"
      >
        Create Account
      </button>
    </div>
  );
}
